CREATE DATABASE IF NOT EXISTS example;
use example;
create table if not exists users(
id int,
name varchar(255)
);

select * from users;


